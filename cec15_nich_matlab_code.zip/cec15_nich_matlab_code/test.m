% Calculation for positions of local optima after shift and rotation for
% CEC15
% J. J. Liang
% Oct. 25th 2014

D_choose=[5,10,20;2,5,8;2,3,4;5,10,20;2,3,4;4,6,8;6,10,16;2,3,4];
for func_num=1:8
    for d=1:3
        D=D_choose(func_num,d);
        if func_num==1 %Two-Peak Trap
            optima=[];O1=[];O2=[];O3=[];
            O_original=[20,0];O_orig_num=2;
            O_global=repmat(O_original(1),1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %            Oshift=zeros(1,D);M=eye(D,D);
            optima=repmat(O_original(1),1,D);
            O1=repmat(optima,D,1);
            O1(logical(eye(size(O1))))=O_original(2);
            if D>2
                for i=1:D
                    O2=repmat(O1(i,:),D,1);
                    O2(logical(eye(size(O1))))=O_original(2);
                    O3=[O3;O2];
                end
                optima=[optima;O3];
            else
                [a,b]=ndgrid(1:2);
                a=O_original(a);
                b=O_original(b);
                optima=[a(:),b(:)];
            end
            optima=unique(optima,'rows');
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima+repmat(Oshift(1:D),size(optima,1),1);
            func_num,D,f=cec15_nich_func(optima',func_num)
            
        elseif func_num==2    %Five-Uneven-Peak Trap
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0   30   5   22.5   12.5];O_orig_num=5;
            O_global=repmat(O_original(1),1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %             Oshift=zeros(1,D);M=eye(D,D);
%             optima=repmat(O_original(1),1,D);
%             O1=repmat(optima,D,1);
%             O1(logical(eye(size(O1))))=O_original(2);
%             if D>2
%                 for i=1:D
%                     O2=repmat(O1(i,:),D,1);
%                     O2(logical(eye(size(O1))))=O_original(2);
%                     O3=[O3;O2];
%                 end
%                 optima=[optima;O3]; %global: 1,5,21,25
%             else
%                 [a,b]=ndgrid(1:5);
%                 a=O_original(a);
%                 b=O_original(b);
%                 optima=[a(:),b(:)];
%             end
if D==2
            a=repmat(1:O_orig_num,1,D);
            b=nchoosek(a,D);
            a=unique(b,'rows');
            optima=O_original(a);
else
            a=repmat(1:2,1,D);
            b=nchoosek(a,D);
            a=unique(b,'rows');
            optima=O_original(a);
end
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
        elseif func_num==3         % - Equal Maxima
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0.1   0.3   0.5   0.7   0.9];O_orig_num=5;%O_orig_num^D
            O_global=repmat(O_original(1),1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %             Oshift=zeros(1,D);M=eye(D,D);
            %             if D==2
            %                 [a,b]=ndgrid(1:O_orig_num);
            %                 a=O_original(a);
            %                 b=O_original(b);
            %                 optima=[a(:),b(:)];
            %             elseif D==3
            %                 [a,b,c]=ndgrid(1:O_orig_num);
            %                 a=O_original(a);
            %                 b=O_original(b);
            %                 c=O_original(c);
            %                 A=[a(:),b(:),c(:)];
            %             elseif D==4
            %                 [a,b,c,d]=ndgrid(1:O_orig_num);
            %                 a=O_original(a);
            %                 b=O_original(b);
            %                 c=O_original(c);
            %                 d=O_original(d);
            %                 A=[a(:),b(:),c(:),d(:)];
            %             elseif D==5
            %                 [a,b,c,d,e]=ndgrid(1:O_orig_num);
            %                 a=O_original(a);
            %                 b=O_original(b);
            %                 c=O_original(c);
            %                 d=O_original(d);
            %                 e=O_original(e);
            %                 A=[a(:),b(:),c(:),d(:),e(:)];
            %             end
            a=repmat(1:O_orig_num,1,D);
            b=nchoosek(a,D);
            a=unique(b,'rows');
            optima=O_original(a);
            optima=unique(optima,'rows');
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*20+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
        elseif func_num==4 %Decreasing Maxima
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0.1   0.29942   0.49883   0.69825   0.89767];O_orig_num=5;
            O_global=repmat(O_original(1),1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %             Oshift=zeros(1,D);M=eye(D,D);
            optima=repmat(O_original(1),1,D);
            O1=repmat(optima,D,1);
            O1(logical(eye(size(O1))))=O_original(2);
            if D>2
                for i=1:D
                    O2=repmat(O1(i,:),D,1);
                    O2(logical(eye(size(O1))))=O_original(2);
                    O3=[O3;O2];
                end
                optima=[optima;O3];
            else
                [a,b]=ndgrid(1:2);
                a=O_original(a);
                b=O_original(b);
                optima=[a(:),b(:)];
            end
            optima=unique(optima,'rows');
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*20+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
        elseif func_num==5  %Uneven Maxima    f(x*)equal
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0.079699392688696   0.246655   0.450627   0.681420   0.933895];O_orig_num=5;
            O_global=repmat(O_original(1),1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            % Oshift=zeros(1,D);M=eye(D,D);
            a=repmat(1:O_orig_num,1,D);
            b=nchoosek(a,D);
            a=unique(b,'rows');
            optima=O_original(a);
            optima=unique(optima,'rows');
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*20+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
        elseif func_num==6 %even Dimension           Himmelblau��s function      Equal
            optima=[];O1=[];O2=[];O3=[];
            O_original=[3 3.584428 -3.779310 -2.805118;2 -1.848126 -3.283186 3.131312];O_orig_num=4;
            O_global=repmat(O_original(:,1)',1,D/2);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %             Oshift=zeros(1,D);M=eye(D,D);
            a=repmat(1:O_orig_num,1,D/2);
            b=nchoosek(a,D/2);
            a=unique(b,'rows');
            optima=[];
            for i=1:D/2
                optima=[optima,O_original(1,a(:,i))',O_original(2,a(:,i))'];
            end
            %
            %             optima=repmat(O_original(:,1)',1,D/2);
            %             O1=repmat(optima,D/2,1);
            %             for i=1:2:(D-1)
            %                 O1((i+1)/2,i:(i+1))=O_original(:,2)';
            %             end
            %             if D>4
            %                 for i=1:D/2
            %                     O2=repmat(O1(i,:),D,1);
            %                     for j=1:2:(D-1)
            %                         O2((j+1)/2,j:(j+1))=O_original(:,2)';
            %                     end
            %                     O3=[O3;O2];
            %                 end
            %                 optima=[optima;O3];
            %             elseif D>2
            %                 optima=[optima;O1];
            %                 optima=[optima;repmat(O_original(:,2)',1,D/2)];
            %             else
            %                 optima=O_original';
            %             end
            
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*5+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
        elseif func_num==7 %even Dimension              Six-Hump Camel Back         Equal
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0.089842 -0.089842;-0.712656 0.712656];O_orig_num=2;
            O_global=repmat(O_original(:,1)',1,D/2);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %             Oshift=zeros(1,D);M=eye(D,D);
            a=repmat(1:O_orig_num,1,D/2);
            b=nchoosek(a,D/2);
            a=unique(b,'rows');
            optima=[];
            for i=1:D/2
                optima=[optima,O_original(1,a(:,i))',O_original(2,a(:,i))'];
            end
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*20+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
            func_num,D,f=cec15_nich_func(optima',func_num)
            
        elseif func_num==8  %Vincent   f(x*)equal
            optima=[];O1=[];O2=[];O3=[];
            O_original=[0.333; 0.6242; 1.1701; 2.1933; 4.1112; 7.7063];O_orig_num=6;
            O_global=repmat(4.1112,1,D);
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
            %         Oshift=zeros(1,D);M=eye(D,D);
            a=repmat(1:O_orig_num,1,D);
            b=nchoosek(a,D);
            a=unique(b,'rows');
            optima=O_original(a);
            optima=optima-repmat(O_global(1:D),size(optima,1),1);
            optima=optima*inv(M');
            optima=optima.*5+repmat(Oshift(1:D),size(optima,1),1);
%             eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
func_num,D,f=cec15_nich_func(optima',func_num)
        end
    end
end

D_choose=[10,20,30];cf_num=10;
for func_num=9:15
    for d=1:3
        D=D_choose(d);
        eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
        eval(['optima=shift_data_' num2str(func_num) '(1:cf_num,1:D);']);
%          eval(['save optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt optima -ASCII -DOUBLE']);
func_num,D,f=cec15_nich_func(optima',func_num)
    end
end


%            eval(['load input_data/optima_positions_' num2str(func_num) '_' num2str(D) 'D.txt;']);
%             eval(['optima=optima_positions_' num2str(func_num) '_' num2str(D) ';']);
