% clear all
% mex cec15_nich_func.cpp -DWINDOWS

func_num=1;
% D=10;
Xmin=-100;
Xmax=100;
pop_size=100;
iter_max=100;
runs=1;
fhd=str2func('cec15_nich_func');
for i=1:15
    func_num=i;
    if i==1||i==2||i==4
        D=5;
    elseif i==3 || i==5
        D=4;
    elseif i==6||i==7
        D=6;
    else 
        D=10;
    end
        
    for j=1:runs
        i,j,
        [gbest,gbestval,FES]= PSO_func(fhd,D,pop_size,iter_max,Xmin,Xmax,func_num);
%         xbest(j,:)=gbest;
        fbest(i,j)=gbestval;
        fbest(i,j)
    end
    f_mean(i)=mean(fbest(i,:));
end

% for i=1:15
% eval(['load input_data/shift_data_' num2str(i) '.txt']);
% eval(['O=shift_data_' num2str(i) '(1,1:D);']);
% f(i)=cec15_nich_func(O',i);i,f(i)
% end