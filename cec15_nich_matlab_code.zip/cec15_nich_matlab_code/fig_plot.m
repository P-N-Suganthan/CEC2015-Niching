%mex cec15_nich_func.cpp -DWINDOWS

clear all,
close all
D=2;
for func_num=8:8
    recalculate_local
            eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
            eval(['Oshift=shift_data_' num2str(func_num) '(1:D);']);
            eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
            eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
% Oshift=[0,0];
    x=-100:2:100;y=x;
    a=40;b=a;step=0.5;x=(Oshift(1)-a):step:(Oshift(1)+b);y=(Oshift(2)-a):step:(Oshift(2)+b);
    for i=1:length(x)
        z(2,:)=y;
        z(1,:)=x(i);
%         f(:,i) =-eobj(z',8);
        f(:,i) = cec15_nich_func(z,func_num);
    end
%        figure, surfc(x,y,f);
%        axis([min(x) max(x) min(y) max(y)])
     figure, contour(x,y,f,50);hold on;
     plot(optima(:,1),optima(:,2),'r*')
%      plot(Oshift(1),Oshift(2),'r*'); 
     hold off
end

% for func_num=15:15
%             eval(['load input_data/shift_data_' num2str(func_num) '.txt']);
%             eval(['Oshift=shift_data_' num2str(func_num) '(:,1:D);']);
%             eval(['load input_data/M_' num2str(func_num) '_D' num2str(D) '.txt']);
%             eval(['M=M_' num2str(func_num) '_D' num2str(D) ';']);
% 
%     x=-100:2:100;y=x; 
%     a=30;step=1;i=6;
%     x=(Oshift(i,1)-a):step:(Oshift(i,1)+a);y=(Oshift(i,2)-a):step:(Oshift(i,2)+a);
%     for i=1:length(x)
%         z(2,:)=y;
%         z(1,:)=x(i);
% %         f(:,i) =-eobj(z',8);
%         f(:,i) = cec15_nich_func(z,func_num);
%     end
%        figure, surfc(x,y,f);
%        axis([min(x) max(x) min(y) max(y)])
% %      figure, contour(x,y,f,1000);hold on;
% %      plot(optima(:,1),optima(:,2),'r*')
%      hold on;
%      plot(Oshift(:,1),Oshift(:,2),'r*'); 
%      hold off
% end